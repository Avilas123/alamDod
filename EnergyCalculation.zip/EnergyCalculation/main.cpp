/*
 This program counts the number of samples in three different normalized amplitude
 * ranges and classifies the signal as being in one of three different classes
 */

/* 
 * File:   main.cpp
 * Author: Sarfaraz Jelil
 *
 * Created on 31 December, 2015, 2:36 PM
 * 
 * RETURN VALUES:
 * if the checkEnergy() function returns -1, the signal has very low energy
 * if the checkEnergy() function returns 0, the signal has sufficient energy
 * if the checkEnergy() function returns 1, the signal is clipped
 */

#include <cstdlib>
#include<iostream>
#include<cstring>
#include<sndfile.hh>
#include <fstream>
#include<math.h>
#include"mfcc_globals.h"
#include"mfcc_defines.h"
using namespace std;

class SpeechFile
{
    double *signal;
    int numOfSamples;
    
    public:
    void readData(char*);
    int checkEnergy(char*);
    float* vad_enrthr(char*, int*,int*);
    double findMaxSampleValue(double*, int);
};


void SpeechFile :: readData(char* filename)
{
    
    
    //cout << "The file name is " << filename <<endl;
    
    /// create object of sndfilehandle
    SndfileHandle sfile;
    sfile = SndfileHandle(filename);  /// open the file
    numOfSamples = sfile.frames() * sfile.channels();   //// number of samples = samples * channels;
    
    /// allocate memory for the signal
    
    signal = (double*)malloc(numOfSamples*sizeof(double));
    sfile.read(signal,numOfSamples);  //// read the wave file and store the values in signal 
    ofstream outfile;
    outfile.open("test.txt");
    for(int i=0;i<numOfSamples;i++)
    {
        outfile << signal[i] <<endl;
    }

}

int SpeechFile :: checkEnergy(char *filename)
{
    //// do the voice activity detection and select only the speech frames
    float *speech_non_speech_frames;
    int numFramesTotal, numSpeechFrames;
    speech_non_speech_frames = vad_enrthr(filename,&numFramesTotal,&numSpeechFrames);
    
    
    
    
    double *vad_signal = (double*)malloc(numSpeechFrames*FRAMESIZE * sizeof(double));
    for(int i=0;i<numSpeechFrames*FRAMESIZE;i++)
        vad_signal[i]=0;
        
    int ptr=0;
    
    //// for printing timing information
    float frameshift=80, start=1;
    
    for(int i=0;i<numFramesTotal;i++)
    {
        cout<<(start/8000)*10000000<< " " << (start+frameshift)/8000*10000000 << " "<<speech_non_speech_frames[i]<<"\n";
        if(speech_non_speech_frames[i] == 1)
        {
            int factor = i*FRAMESHIFT;
            for(int j=0;j<FRAMESIZE;j++)
            {
                vad_signal[ptr] = signal[factor+j];  /// read the samples in the speech frames only
                ptr++;
            }
        }
        
        start = start+frameshift;
    }
    
    
    //// take the speech signal and normalize the values with the max sample value
    double *norm_signal = (double*)malloc(ptr*sizeof(double));
    double max = findMaxSampleValue(vad_signal,ptr);
    int range1=0, range2=0, range3=0;
    
    //// normalize the signal now
    for(int i=0; i<ptr; i++)
    {
        norm_signal[i] = vad_signal[i]/max;
    }
    
    ofstream outfile;
    outfile.open("test2.txt");
    for(int i=0;i<ptr;i++)
    {
        outfile << norm_signal[i] <<endl;
    }
    
    
    //// find how many are in the given ranges
    for(int i=0;i<ptr;i++)
    {
        if(fabs(vad_signal[i])<0.1)
            range1++;
        else if
           (fabs(vad_signal[i])>= 0.1 && fabs(vad_signal[i])<=0.5 )
            range2++;
        else
            range3++;
                
    }
    
    
    //// get the max of the three range variables
    if(range1>range2 && range1>range3 )
        return -1;
    else if(range2>range1 && range2>range3)
        return 0;
    else
        return 1;
    
}

double SpeechFile :: findMaxSampleValue(double *vad_signal, int ptr)
{
    //// find the max
    double max = fabs(vad_signal[0]);
    for(int i=1; i<ptr; i++)
    {
        if(vad_signal[i] > max)
            max = fabs(vad_signal[i]);
    }
    //cout<<"max = "<<max<<endl;
    return max;
}

float* SpeechFile :: vad_enrthr(char *fullpath_input, int *total_no_of_frames, int *no_of_speech_frames){
    
    short *ptr;
	int i, j, k = 0, m, start_point, end_point; 
	int shift, incr = 0;
        int nof_fshift;                   // Actual no of frames of FRAMESIZE obtained after FRAMESHIFT
        int sum_energy=0;
        short *speech_nonspeech_frames;
	float energy, Avg_Energy = 0;
	float *Energy_frames;
	short temp_buff[FRAMESIZE];	          // for temporay storage
        long eoinput;
        int temp_no_speech_frames;
        FILE *fp1_input, *fp2_input, *fp_speech_nonspeech, *fp_starting_end_point, *fp_endpoint,  *fp_no_speech_frames, *fp_avr_enr,*fp_total_no_frames, *fp_nof_fsize;
        
        *no_of_speech_frames = 0;                // used to calculate the no. of speech frames
        int nof_fsize = 0;
	
	if((fp1_input = fopen(fullpath_input,"rb")) == NULL)                               // Opens the input wav file to count the no of frames without FRAMESHIFT
		{
			printf("Unable to open the file %s \n",fullpath_input);
			exit(0);
		}
	else
	{
		fread(&globDataSpeechRecgStruct.header,sizeof(waveStruct),1,fp1_input);	             // Reads input file header information
               
	}
	
 
	if((fp2_input = fopen(fullpath_input,"rb")) == NULL)                               // Opens the input wav file
		{
			printf("Unable to open the %s file\n",fullpath_input);
			exit(0);
		}
	else
	{
		fseek(fp2_input, sizeof(waveStruct), SEEK_SET);                           // Moving the pointer next to header data
	}   
       
	     

	
	while(1==1)                                                                         // Calculating total no. of frames without overlapping.
		{
			fread(temp_buff, sizeof(short), FRAMESIZE, fp1_input);              // Using temp_buff for just a temporary fread()

                        if(feof(fp1_input)) break;

			(nof_fsize)++;
		}


	fclose(fp1_input);

         
        nof_fshift=((FRAMESIZE/FRAMESHIFT)*(nof_fsize))-((FRAMESIZE/FRAMESHIFT)-1);   // Calculating the no of frames of FRAMESHIFT
 
	ptr = (short*)malloc((FRAMESIZE * (nof_fsize)) * sizeof(short));              // Allocating contiguous memory to store the complete data of Input wav file

	Energy_frames = (float *)malloc( nof_fshift * sizeof(float) );                // Allocating contiguous memory to store the energies of every frame
        
        speech_nonspeech_frames = (short *)malloc( nof_fshift * sizeof(short) );       // Allocating contiguous memory to store the boolean value whether a frame is speech or non-speech 


        fread(ptr, sizeof(short), (nof_fsize)*FRAMESIZE, fp2_input);                        // Reading complete data as single chunk
			
	fclose(fp2_input);

	shift = 0;

       eoinput= ( (nof_fsize) * FRAMESIZE ) - FRAMESHIFT;
 /**
     The below while loop is used for calculating the energy of each frame and storing it in the Energy_frames array

*/       
       
       while(shift != eoinput)
		{
			        for(i=0; i<FRAMESIZE; i++)                    // Calculating channel data for one frame of 20 milli seconds
				  {
					
					
						globDataSpeechRecgStruct.sample_value[i] = (float)(*ptr)/(float)pow(2,(globDataSpeechRecgStruct.header.Bits_Per_Sample-1));   
                                                ptr++;
								
				   }
                        

					energy = 0;
					for(i=0; i<FRAMESIZE; i++)           // Calculating energy of the frame
						{
							energy = (float)energy + (float)pow(globDataSpeechRecgStruct.sample_value[i], 2);
						}
					Energy_frames[incr] = energy;                                    
					incr++;

                        
                        ptr = ptr - FRAMESHIFT;
			shift = shift + FRAMESHIFT;		
                                        								

		}                                     // While Loop ends



      for(i=0; i<nof_fshift; i++)                    // Calculating average energy
      {
	Avg_Energy = Avg_Energy + Energy_frames[i];     
      }
       Avg_Energy = Avg_Energy/nof_fshift;
      // printf("Average energy is : %f\n",Avg_Energy);

/*for(i=0;i<nof_fshift;i++)
{
printf("energy_frames : %f\n",Energy_frames[i]);
}*/


/*************** Comparing with threshold energy and passing 1 if the frame is speech frame else 0 ***********************
          while( k<=nof_fshift )
          {
            for( m=0;m<4;m++)
           {

            if((Energy_frames[k+m] > (0.66*Avg_Energy))) 
	     {
					
                speech_nonspeech_frames[k+m]=1;                   
                //(*no_of_speech_frames)++;
			
            }

            else
            {
               speech_nonspeech_frames[k+m]=0;
            } 

           }
        for( m=0;m<4;m++)
        {
          sum_energy=sum_energy + speech_nonspeech_frames[k+m];
        }
       
        if(sum_energy==4)
         break;
         
        else
         { 
            sum_energy=0;
            k++;
         }
 				
         }

  


*/
k=0;

/*************** Comparing with threshold energy and passing 1 if the frame is speech frame else 0 ***********************/
          while( k<=nof_fshift )
          {
            if((Energy_frames[k] > (0.66*Avg_Energy))) 
	     {
					
                speech_nonspeech_frames[k]=1;                   
                (*no_of_speech_frames)++;
			
            }

            else
            {
               speech_nonspeech_frames[k]=0;
            } 

            k++;
 				
         }

        temp_no_speech_frames = *no_of_speech_frames;
   
   

      
	        
                ptr = ptr - eoinput;
		free(ptr);
		//free(Energy_frames);
              
              
               
                *total_no_of_frames = nof_fshift;
                
		return(Energy_frames);		
}	// vad_enrthr() ENDS HERE


int main(int argc, char** argv) {
    
    /*check for proper number of inputs*/
    
    if(argc !=2 )
    {
        cout<< "usage: ./program name   wavFileName";
        exit(1);
    }
    
    int energyLevel;
    char *filename = (char*)malloc(1000*sizeof(char));
    strcpy(filename,argv[1]);    /// copy the wavfile name supplied as argument to the variable
    
    SpeechFile sFile;   /// create an object of speechFile class
    sFile.readData(filename);  /// first read the samples in the speech file
    energyLevel = sFile.checkEnergy(filename);
    //cout << energyLevel<<endl;
    
    return 0;
}

