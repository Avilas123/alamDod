/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   vad.h
 * Author: Sarfaraz Jelil
 *
 * Created on 5 January, 2016, 10:26 AM
 */

#ifndef VAD_H
#define VAD_H

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* VAD_H */

